const fecha = new Date();
document.getElementById("fecha").textContent = fecha.toLocaleDateString("es-ES");

function saludar() {
    alert("¡Bienvenido al mundo del teatro!");
}

function mostrarInformacion() {
    const informacion = document.getElementById("informacion");
    informacion.style.display = "block";
}

function ocultarInformacion() {
    const informacion = document.getElementById("informacion");
    informacion.style.display = "none";
}
function cambiarTexto() {
    const texto = document.getElementById("texto");
    texto.innerHTML = "¡El teatro no solo se ve, se siente!";
}
function cambiarColor() {
    const texto2 = document.getElementById("texto2");
    texto2.style.color = "red";
}
function mostrartecla(event) {
    const tecla = document.getElementById("tecla");
    tecla.innerHTML = "Tecla presionada: " + event.key;
}

function elegircomputador(tipo) {
    const opcionSeleccionada = document.getElementById("opcionSeleccionada");
    opcionSeleccionada.innerHTML = "Opción seleccionada: " + tipo;
}
